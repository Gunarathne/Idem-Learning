package com.example.madapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GettingStarted extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getting_started);
    }
}